<?php
// models/employee_model.php
require_once(__DIR__ . '/database.php');

function get_employee_by_id($employee_id) {
    global $db;
    $stmt = $db->prepare('SELECT * FROM employees WHERE employee_id = :employee_id');
    $stmt->execute([':employee_id' => $employee_id]);
    return $stmt->fetch();
}

function get_all_employees() {
    global $db;
    $stmt = $db->query('SELECT * FROM employees ORDER BY level, last_name');
    return $stmt->fetchAll();
}

function get_technicians() {
    global $db;
    $stmt = $db->query("SELECT * FROM employees WHERE level = 'Technician' ORDER BY last_name");
    return $stmt->fetchAll();
}

function insert_employee($data) {
    global $db;
    $stmt = $db->prepare('INSERT INTO employees (employee_id, first_name, last_name, email, phone_extension, level, password) 
                          VALUES (:employee_id, :first_name, :last_name, :email, :phone_extension, :level, :password)');
    return $stmt->execute($data);
}

function update_employee($data) {
    global $db;
    $stmt = $db->prepare('UPDATE employees SET first_name = :first_name, last_name = :last_name, email = :email, 
                          phone_extension = :phone_extension, level = :level WHERE employee_id = :employee_id');
    return $stmt->execute($data);
}

function update_employee_password($employee_id, $hashed_password) {
    global $db;
    $stmt = $db->prepare('UPDATE employees SET password = :password WHERE employee_id = :employee_id');
    return $stmt->execute([':password' => $hashed_password, ':employee_id' => $employee_id]);
}

function get_technician_workload_counts() {
    global $db;
    $query = "SELECT e.employee_id, e.first_name, e.last_name, 
                     COUNT(c.complaint_id) AS open_count 
              FROM employees e 
              LEFT JOIN complaints c ON e.employee_id = c.assigned_employee_id AND c.status = 'Open'
              WHERE e.level = 'Technician'
              GROUP BY e.employee_id, e.first_name, e.last_name";
    return $db->query($query)->fetchAll();
}
?>