<?php
// models/customer_model.php
require_once(__DIR__ . '/database.php');

function get_customer_by_email($email) {
    global $db;
    $stmt = $db->prepare('SELECT * FROM customers WHERE email = :email');
    $stmt->execute([':email' => $email]);
    return $stmt->fetch();
}

function get_customer_by_id($id) {
    global $db;
    $stmt = $db->prepare('SELECT * FROM customers WHERE customer_id = :id');
    $stmt->execute([':id' => $id]);
    return $stmt->fetch();
}

function get_all_customers() {
    global $db;
    $stmt = $db->query('SELECT * FROM customers ORDER BY last_name, first_name');
    return $stmt->fetchAll();
}

function insert_customer($data) {
    global $db;
    $stmt = $db->prepare('INSERT INTO customers (email, first_name, last_name, street_address, city, state, zip_code, phone_number, password) 
                          VALUES (:email, :first_name, :last_name, :street_address, :city, :state, :zip_code, :phone_number, :password)');
    return $stmt->execute($data);
}

function update_customer($data) {
    global $db;
    $stmt = $db->prepare('UPDATE customers SET email = :email, first_name = :first_name, last_name = :last_name, 
                          street_address = :street_address, city = :city, state = :state, zip_code = :zip_code, phone_number = :phone_number 
                          WHERE customer_id = :customer_id');
    return $stmt->execute($data);
}
?>