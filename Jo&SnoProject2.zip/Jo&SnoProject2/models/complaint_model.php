<?php
// models/complaint_model.php
require_once(__DIR__ . '/database.php');

function get_all_products() {
    global $db;
    return $db->query('SELECT * FROM products ORDER BY product_name')->fetchAll();
}

function get_all_complaint_types() {
    global $db;
    return $db->query('SELECT * FROM complaint_types ORDER BY type_name')->fetchAll();
}

function insert_complaint($data) {
    global $db;
    $stmt = $db->prepare('INSERT INTO complaints (customer_id, product_id, type_id, description, image_path, status) 
                          VALUES (:customer_id, :product_id, :type_id, :description, :image_path, "Open")');
    return $stmt->execute($data);
}

function get_customer_complaints($customer_id) {
    global $db;
    $stmt = $db->prepare('SELECT c.*, p.product_name, t.type_name FROM complaints c 
                          JOIN products p ON c.product_id = p.product_id 
                          JOIN complaint_types t ON c.type_id = t.type_id 
                          WHERE c.customer_id = :customer_id ORDER BY c.complaint_id DESC');
    $stmt->execute([':customer_id' => $customer_id]);
    return $stmt->fetchAll();
}

function get_tech_complaints($employee_id) {
    global $db;
    $stmt = $db->prepare('SELECT c.*, p.product_name, t.type_name, cu.first_name, cu.last_name, cu.email FROM complaints c 
                          JOIN products p ON c.product_id = p.product_id 
                          JOIN complaint_types t ON c.type_id = t.type_id 
                          JOIN customers cu ON c.customer_id = cu.customer_id
                          WHERE c.assigned_employee_id = :employee_id ORDER BY c.status DESC, c.complaint_id DESC');
    $stmt->execute([':employee_id' => $employee_id]);
    return $stmt->fetchAll();
}

function get_complaint_by_id($complaint_id) {
    global $db;
    $stmt = $db->prepare('SELECT c.*, p.product_name, t.type_name, cu.first_name, cu.last_name, cu.email, cu.phone_number 
                          FROM complaints c 
                          JOIN products p ON c.product_id = p.product_id 
                          JOIN complaint_types t ON c.type_id = t.type_id 
                          JOIN customers cu ON c.customer_id = cu.customer_id
                          WHERE c.complaint_id = :complaint_id');
    $stmt->execute([':complaint_id' => $complaint_id]);
    return $stmt->fetch();
}

function update_complaint_by_tech($complaint_id, $tech_notes, $status, $resolution_date, $resolution_notes) {
    global $db;
    $stmt = $db->prepare('UPDATE complaints SET technician_notes = :tech_notes, status = :status, 
                          resolution_date = :res_date, resolution_notes = :res_notes WHERE complaint_id = :complaint_id');
    return $stmt->execute([
        ':tech_notes' => $tech_notes,
        ':status' => $status,
        ':res_date' => empty($resolution_date) ? null : $resolution_date,
        ':res_notes' => $resolution_notes,
        ':complaint_id' => $complaint_id
    ]);
}

function get_open_complaints_assigned() {
    global $db;
    return $db->query("SELECT c.*, p.product_name, t.type_name, CONCAT(e.first_name, ' ', e.last_name) AS tech_name 
                       FROM complaints c 
                       JOIN products p ON c.product_id = p.product_id 
                       JOIN complaint_types t ON c.type_id = t.type_id 
                       JOIN employees e ON c.assigned_employee_id = e.employee_id
                       WHERE c.status = 'Open' AND c.assigned_employee_id IS NOT NULL")->fetchAll();
}

function get_open_complaints_unassigned() {
    global $db;
    return $db->query("SELECT c.*, p.product_name, t.type_name FROM complaints c 
                       JOIN products p ON c.product_id = p.product_id 
                       JOIN complaint_types t ON c.type_id = t.type_id 
                       WHERE c.status = 'Open' AND c.assigned_employee_id IS NULL")->fetchAll();
}

function assign_complaint_tech($complaint_id, $employee_id) {
    global $db;
    $stmt = $db->prepare('UPDATE complaints SET assigned_employee_id = :emp_id WHERE complaint_id = :c_id');
    return $stmt->execute([':emp_id' => empty($employee_id) ? null : $employee_id, ':c_id' => $complaint_id]);
}
?>