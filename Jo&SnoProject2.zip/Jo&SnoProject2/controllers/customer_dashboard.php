<?php
if (session_status() === PHP_SESSION_NONE) session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Customer Dashboard</title>
    <style>
        body { font-family: Arial, sans-serif; background: #f4f6f9; margin: 0; padding: 20px; }
        .container { max-width: 800px; margin: 0 auto; background: #fff; padding: 25px; border-radius: 8px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); }
        .header { display: flex; justify-content: space-between; align-items: center; border-bottom: 2px solid #eee; padding-bottom: 10px; }
        .form-group { margin-bottom: 15px; }
        label { display: block; font-weight: bold; margin-bottom: 5px; }
        select, textarea, input[type="file"] { width: 100%; padding: 10px; box-sizing: border-box; border: 1px solid #ccc; border-radius: 4px; }
        button { background: #28a745; color: #fff; padding: 10px 20px; border: none; border-radius: 4px; cursor: pointer; font-size: 16px; }
        button:hover { background: #218838; }
        table { width: 100%; border-collapse: collapse; margin-top: 25px; }
        table, th, td { border: 1px solid #ddd; }
        th, td { padding: 10px; text-align: left; font-size: 14px; }
        th { background: #f2f2f2; }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h2>Customer Support Portal</h2>
            <div>
                <span>Welcome, <strong><?php echo htmlspecialchars($_SESSION['first_name']); ?></strong></span> | 
                <a href="customer_controller.php?action=update_profile">Update Profile</a> | 
                <a href="../controllers/auth_controller.php?action=logout">Logout</a>
            </div>
        </div>

        <?php if (!empty($success_msg)): ?><div style="color:green; margin:15px 0;"><?php echo $success_msg; ?></div><?php endif; ?>

        <h3>Submit New Complaint</h3>
        <form action="customer_controller.php" method="POST" enctype="multipart/form-data">
            <div class="form-group">
                <label>Product / Service</label>
                <select name="product_id" required>
                    <option value="">-- Select Product --</option>
                    <?php foreach ($products as $p): ?>
                        <option value="<?php echo $p['product_id']; ?>"><?php echo htmlspecialchars($p['product_name']); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group">
                <label>Complaint Category</label>
                <select name="type_id" required>
                    <option value="">-- Select Category --</option>
                    <?php foreach ($complaint_types as $t): ?>
                        <option value="<?php echo $t['type_id']; ?>"><?php echo htmlspecialchars($t['type_name']); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group">
                <label>Detailed Description</label>
                <textarea name="description" rows="4" required></textarea>
            </div>
            <div class="form-group">
                <label>Upload Screenshot (Optional)</label>
                <input type="file" name="complaint_image" accept="image/*">
            </div>
            <button type="submit" name="submit_complaint">Submit Complaint</button>
        </form>

        <hr style="margin-top: 30px;">
        <h3>My Submitted Complaints</h3>
        <?php if (empty($my_complaints)): ?>
            <p>No complaints submitted yet.</p>
        <?php else: ?>
            <table>
                <tr>
                    <th>ID</th><th>Product</th><th>Category</th><th>Status</th><th>Technician Notes</th><th>Resolution</th>
                </tr>
                <?php foreach ($my_complaints as $c): ?>
                <tr>
                    <td>#<?php echo $c['complaint_id']; ?></td>
                    <td><?php echo htmlspecialchars($c['product_name']); ?></td>
                    <td><?php echo htmlspecialchars($c['type_name']); ?></td>
                    <td><strong><?php echo htmlspecialchars($c['status']); ?></strong></td>
                    <td><?php echo htmlspecialchars($c['technician_notes'] ?? 'Pending review'); ?></td>
                    <td><?php echo htmlspecialchars($c['resolution_notes'] ?? 'Pending'); ?></td>
                </tr>
                <?php endforeach; ?>
            </table>
        <?php endif; ?>
    </div>
</body>
</html>