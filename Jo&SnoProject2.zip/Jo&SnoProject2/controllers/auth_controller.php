<?php
// controllers/auth_controller.php
session_start();
require_once(__DIR__ . '/../models/customer_model.php');
require_once(__DIR__ . '/../models/employee_model.php');

$action = $_GET['action'] ?? '';

if ($action === 'logout') {
    session_destroy();
    header('Location: ../index.php');
    exit();
}

// Customer Login Handler
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['customer_login'])) {
    $email = filter_input(INPUT_POST, 'email', FILTER_VALIDATE_EMAIL);
    $password = $_POST['password'] ?? '';

    if ($email && !empty($password)) {
        $customer = get_customer_by_email($email);
        if ($customer && password_verify($password, $customer['password'])) {
            $_SESSION['customer_id'] = $customer['customer_id'];
            $_SESSION['first_name'] = $customer['first_name'];
            $_SESSION['last_name'] = $customer['last_name'];
            header('Location: customer_controller.php?action=dashboard');
            exit();
        }
    }
    $error = "Invalid email or password.";
    include(__DIR__ . '/../views/customer_login.php');
}

// Employee Login Handler
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['employee_login'])) {
    $employee_id = trim($_POST['employee_id'] ?? '');
    $password = $_POST['password'] ?? '';

    if (!empty($employee_id) && !empty($password)) {
        $emp = get_employee_by_id($employee_id);
        if ($emp && password_verify($password, $emp['password'])) {
            $_SESSION['employee_id'] = $emp['employee_id'];
            $_SESSION['first_name'] = $emp['first_name'];
            $_SESSION['level'] = $emp['level'];

            if ($emp['level'] === 'Administrator') {
                header('Location: admin_controller.php?action=dashboard');
            } else {
                header('Location: technician_controller.php?action=dashboard');
            }
            exit();
        }
    }
    $error = "Invalid User ID or Password.";
    include(__DIR__ . '/../views/employee_login.php');
}
?>