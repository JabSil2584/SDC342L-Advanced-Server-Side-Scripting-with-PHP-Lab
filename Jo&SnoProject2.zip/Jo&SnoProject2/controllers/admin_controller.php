<?php
// controllers/admin_controller.php
session_start();
require_once(__DIR__ . '/../models/customer_model.php');
require_once(__DIR__ . '/../models/employee_model.php');
require_once(__DIR__ . '/../models/complaint_model.php');

if (!isset($_SESSION['employee_id']) || $_SESSION['level'] !== 'Administrator') {
    header('Location: ../views/employee_login.php');
    exit();
}

$action = $_GET['action'] ?? 'dashboard';

// Add/Update Employee
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_employee'])) {
    $employee_id = trim($_POST['employee_id'] ?? '');
    $first_name = trim($_POST['first_name'] ?? '');
    $last_name = trim($_POST['last_name'] ?? '');
    $email = filter_input(INPUT_POST, 'email', FILTER_VALIDATE_EMAIL);
    $phone_extension = trim($_POST['phone_extension'] ?? '');
    $level = $_POST['level'] ?? 'Technician';
    $password = $_POST['password'] ?? '';
    $is_edit = isset($_POST['is_edit']) && $_POST['is_edit'] === '1';

    if ($is_edit) {
        update_employee([
            'employee_id' => $employee_id, 'first_name' => $first_name, 'last_name' => $last_name,
            'email' => $email, 'phone_extension' => $phone_extension, 'level' => $level
        ]);
    } else {
        $hashed_pw = password_hash(empty($password) ? 'Pa$$word1' : $password, PASSWORD_DEFAULT);
        insert_employee([
            'employee_id' => $employee_id, 'first_name' => $first_name, 'last_name' => $last_name,
            'email' => $email, 'phone_extension' => $phone_extension, 'level' => $level, 'password' => $hashed_pw
        ]);
    }
    header('Location: admin_controller.php?action=employees');
    exit();
}

// Assign Complaint
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['assign_complaint'])) {
    $complaint_id = filter_input(INPUT_POST, 'complaint_id', FILTER_VALIDATE_INT);
    $employee_id = trim($_POST['employee_id'] ?? '');
    assign_complaint_tech($complaint_id, $employee_id);
    header('Location: admin_controller.php?action=dashboard');
    exit();
}

if ($action === 'customers') {
    $customers = get_all_customers();
    include(__DIR__ . '/../views/admin_customers.php');
} elseif ($action === 'edit_customer') {
    $id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        update_customer([
            'customer_id' => $id,
            'email' => $_POST['email'],
            'first_name' => $_POST['first_name'],
            'last_name' => $_POST['last_name'],
            'street_address' => $_POST['street_address'],
            'city' => $_POST['city'],
            'state' => $_POST['state'],
            'zip_code' => $_POST['zip_code'],
            'phone_number' => $_POST['phone_number']
        ]);
        header('Location: admin_controller.php?action=customers');
        exit();
    }
    $customer = get_customer_by_id($id);
    include(__DIR__ . '/../views/admin_customer_edit.php');
} elseif ($action === 'employees') {
    $employees = get_all_employees();
    include(__DIR__ . '/../views/admin_employees.php');
} elseif ($action === 'edit_employee') {
    $id = $_GET['id'] ?? null;
    $employee = $id ? get_employee_by_id($id) : null;
    include(__DIR__ . '/../views/admin_employee_edit.php');
} elseif ($action === 'assign') {
    $open_unassigned = get_open_complaints_unassigned();
    $technicians = get_technicians();
    include(__DIR__ . '/../views/admin_assign_complaints.php');
} else {
    $open_assigned = get_open_complaints_assigned();
    $open_unassigned = get_open_complaints_unassigned();
    $tech_workloads = get_technician_workload_counts();
    include(__DIR__ . '/../views/admin_dashboard.php');
}
?>