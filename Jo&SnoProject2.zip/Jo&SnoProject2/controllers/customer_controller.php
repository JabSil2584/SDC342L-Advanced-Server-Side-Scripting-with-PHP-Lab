<?php
// controllers/customer_controller.php
session_start();
require_once(__DIR__ . '/../models/customer_model.php');
require_once(__DIR__ . '/../models/complaint_model.php');

$action = $_GET['action'] ?? 'dashboard';

// Registration
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['register'])) {
    $errors = [];
    $email = filter_input(INPUT_POST, 'email', FILTER_VALIDATE_EMAIL);
    $first_name = trim($_POST['first_name'] ?? '');
    $last_name = trim($_POST['last_name'] ?? '');
    $street_address = trim($_POST['street_address'] ?? '');
    $city = trim($_POST['city'] ?? '');
    $state = strtoupper(trim($_POST['state'] ?? ''));
    $zip_code = trim($_POST['zip_code'] ?? '');
    $phone_number = trim($_POST['phone_number'] ?? '');
    $password = $_POST['password'] ?? '';

    if (!$email) $errors[] = "Valid email address is required.";
    if (empty($first_name) || strlen($first_name) > 50) $errors[] = "First name is required (max 50 chars).";
    if (empty($last_name) || strlen($last_name) > 50) $errors[] = "Last name is required (max 50 chars).";
    if (empty($street_address) || strlen($street_address) > 100) $errors[] = "Street address required (max 100 chars).";
    if (empty($city) || strlen($city) > 50) $errors[] = "City required (max 50 chars).";
    if (strlen($state) !== 2) $errors[] = "State must be exactly 2 characters.";
    if (!preg_match('/^\d{5}(-\d{4})?$/', $zip_code)) $errors[] = "Valid zip code required.";
    if (empty($phone_number) || strlen($phone_number) > 20) $errors[] = "Valid phone number required.";
    if (strlen($password) < 6) $errors[] = "Password must be at least 6 characters.";

    if (empty($errors)) {
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
        if (insert_customer([
            'email' => $email, 'first_name' => $first_name, 'last_name' => $last_name,
            'street_address' => $street_address, 'city' => $city, 'state' => $state,
            'zip_code' => $zip_code, 'phone_number' => $phone_number, 'password' => $hashed_password
        ])) {
            header('Location: ../views/customer_login.php?registered=1');
            exit();
        } else {
            $errors[] = "Email address already registered.";
        }
    }
    include(__DIR__ . '/../views/customer_register.php');
    exit();
}

// Authentication Check
if (!isset($_SESSION['customer_id'])) {
    header('Location: ../views/customer_login.php');
    exit();
}

$customer_id = $_SESSION['customer_id'];

// Profile Update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_profile'])) {
    $errors = [];
    $email = filter_input(INPUT_POST, 'email', FILTER_VALIDATE_EMAIL);
    $first_name = trim($_POST['first_name'] ?? '');
    $last_name = trim($_POST['last_name'] ?? '');
    $street_address = trim($_POST['street_address'] ?? '');
    $city = trim($_POST['city'] ?? '');
    $state = strtoupper(trim($_POST['state'] ?? ''));
    $zip_code = trim($_POST['zip_code'] ?? '');
    $phone_number = trim($_POST['phone_number'] ?? '');

    if (empty($errors)) {
        update_customer([
            'customer_id' => $customer_id, 'email' => $email, 'first_name' => $first_name,
            'last_name' => $last_name, 'street_address' => $street_address, 'city' => $city,
            'state' => $state, 'zip_code' => $zip_code, 'phone_number' => $phone_number
        ]);
        $success_msg = "Profile updated successfully.";
    }
    $customer = get_customer_by_id($customer_id);
    include(__DIR__ . '/../views/customer_update.php');
    exit();
}

// Submit Complaint
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit_complaint'])) {
    $product_id = filter_input(INPUT_POST, 'product_id', FILTER_VALIDATE_INT);
    $type_id = filter_input(INPUT_POST, 'type_id', FILTER_VALIDATE_INT);
    $description = trim($_POST['description'] ?? '');
    $image_path = null;

    if (isset($_FILES['complaint_image']) && $_FILES['complaint_image']['error'] === UPLOAD_ERR_OK) {
        $ext = strtolower(pathinfo($_FILES['complaint_image']['name'], PATHINFO_EXTENSION));
        if (in_array($ext, ['jpg', 'jpeg', 'png', 'gif'])) {
            $upload_dir = __DIR__ . '/../uploads/';
            if (!is_dir($upload_dir)) mkdir($upload_dir, 0777, true);
            $new_name = uniqid('img_', true) . '.' . $ext;
            if (move_uploaded_file($_FILES['complaint_image']['tmp_name'], $upload_dir . $new_name)) {
                $image_path = 'uploads/' . $new_name;
            }
        }
    }

    if ($product_id && $type_id && !empty($description)) {
        insert_complaint([
            'customer_id' => $customer_id,
            'product_id' => $product_id,
            'type_id' => $type_id,
            'description' => $description,
            'image_path' => $image_path
        ]);
        $success_msg = "Complaint submitted successfully.";
    }
}

if ($action === 'update_profile') {
    $customer = get_customer_by_id($customer_id);
    include(__DIR__ . '/../views/customer_update.php');
} else {
    $products = get_all_products();
    $complaint_types = get_all_complaint_types();
    $my_complaints = get_customer_complaints($customer_id);
    include(__DIR__ . '/../views/customer_dashboard.php');
}
?>