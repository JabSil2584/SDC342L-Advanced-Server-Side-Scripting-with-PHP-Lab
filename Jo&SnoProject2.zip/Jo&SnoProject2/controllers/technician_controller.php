<?php
// controllers/technician_controller.php
session_start();
require_once(__DIR__ . '/../models/complaint_model.php');
require_once(__DIR__ . '/../models/employee_model.php');

if (!isset($_SESSION['employee_id']) || $_SESSION['level'] !== 'Technician') {
    header('Location: ../views/employee_login.php');
    exit();
}

$employee_id = $_SESSION['employee_id'];
$action = $_GET['action'] ?? 'dashboard';

// Change Password
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['change_password'])) {
    $new_pw = $_POST['new_password'] ?? '';
    if (strlen($new_pw) >= 6) {
        update_employee_password($employee_id, password_hash($new_pw, PASSWORD_DEFAULT));
        $success_msg = "Password updated successfully.";
    } else {
        $error = "Password must be at least 6 characters.";
    }
    include(__DIR__ . '/../views/tech_change_password.php');
    exit();
}

// Update Complaint
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_complaint'])) {
    $complaint_id = filter_input(INPUT_POST, 'complaint_id', FILTER_VALIDATE_INT);
    $tech_notes = trim($_POST['technician_notes'] ?? '');
    $status = $_POST['status'] ?? 'Open';
    $resolution_date = $_POST['resolution_date'] ?? null;
    $resolution_notes = trim($_POST['resolution_notes'] ?? '');

    $errors = [];
    if ($status === 'Closed' && empty($resolution_notes)) {
        $errors[] = "Resolution notes are required to mark a complaint resolved.";
    }

    if (empty($errors)) {
        update_complaint_by_tech($complaint_id, $tech_notes, $status, $resolution_date, $resolution_notes);
        header('Location: technician_controller.php?action=dashboard');
        exit();
    } else {
        $complaint = get_complaint_by_id($complaint_id);
        include(__DIR__ . '/../views/tech_update_complaint.php');
        exit();
    }
}

if ($action === 'update') {
    $complaint_id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
    $complaint = get_complaint_by_id($complaint_id);
    include(__DIR__ . '/../views/tech_update_complaint.php');
} elseif ($action === 'password') {
    include(__DIR__ . '/../views/tech_change_password.php');
} else {
    $complaints = get_tech_complaints($employee_id);
    include(__DIR__ . '/../views/tech_dashboard.php');
}
?>