USE `jo&sno`;

-- Clear existing data if necessary
DELETE FROM `products`;
DELETE FROM `complaint_types`;

-- Populate 5 Crypto and Day Trading Products / Services
INSERT INTO `products` (`product_id`, `product_name`, `product_description`) VALUES
(1, 'Bitaxe Mining Rig', 'Open-source hardware ASIC Bitcoin mining device.'),
(2, 'Crypto Trading Bot (EA)', 'Automated algorithmic trading expert advisor.'),
(3, 'Arbitrage Flash Loan Bot', 'Smart contract tool for multi-chain cross-DEX arbitrage.'),
(4, 'Node Hosting & Setup', 'Managed blockchain node infrastructure support.'),
(5, 'Custom Indicator Development', 'Tailored Pine Script and MQL technical indicators.');

-- Populate Complaint Categories
INSERT INTO `complaint_types` (`type_id`, `type_name`) VALUES
(1, 'Product Defect / Hardware Failure'),
(2, 'Software / Bot Execution Error'),
(3, 'Warranty & Return Claim'),
(4, 'Setup & Configuration Assistance');