<?php
// index.php - Main Portal Landing Page
session_start();
include(__DIR__ . '/views/home_view.php');
?>