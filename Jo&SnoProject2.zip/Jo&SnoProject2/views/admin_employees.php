<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Manage Employees</title>
    <style>
        body { font-family: Arial, sans-serif; background: #f4f6f9; padding: 20px; }
        .container { max-width: 900px; margin: 0 auto; background: #fff; padding: 25px; border-radius: 8px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); }
        table { width: 100%; border-collapse: collapse; margin-top: 15px; }
        table, th, td { border: 1px solid #ddd; }
        th, td { padding: 8px; text-align: left; font-size: 13px; }
        th { background: #f2f2f2; }
        .btn { background: #28a745; color: white; padding: 8px 15px; text-decoration: none; border-radius: 4px; display: inline-block; margin-bottom: 15px; font-weight: bold; }
    </style>
</head>
<body>
    <div class="container">
        <h2>Employee List (Administrators & Technicians)</h2>
        <div style="margin-top:15px;">
            <a href="admin_controller.php?action=edit_employee" class="btn">+ Add New Employee</a>
            <a href="admin_controller.php?action=dashboard" style="margin-left: 15px; font-weight:bold; text-decoration:none;">&larr; Back to Dashboard</a>
        </div>
        <table>
            <tr><th>User ID</th><th>Name</th><th>Email</th><th>Extension</th><th>Level</th><th>Action</th></tr>
            <?php foreach ($employees as $emp): ?>
            <tr>
                <td><?php echo htmlspecialchars($emp['employee_id']); ?></td>
                <td><?php echo htmlspecialchars($emp['last_name'] . ', ' . $emp['first_name']); ?></td>
                <td><?php echo htmlspecialchars($emp['email']); ?></td>
                <td><?php echo htmlspecialchars($emp['phone_extension']); ?></td>
                <td><?php echo htmlspecialchars($emp['level']); ?></td>
                <td><a href="admin_controller.php?action=edit_employee&id=<?php echo urlencode($emp['employee_id']); ?>">Edit</a></td>
            </tr>
            <?php endforeach; ?>
        </table>
    </div>
</body>
</html>