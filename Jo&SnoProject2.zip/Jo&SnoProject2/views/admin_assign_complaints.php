<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Assign Complaints</title>
    <style>
        body { font-family: Arial, sans-serif; background: #f4f6f9; padding: 20px; }
        .container { max-width: 900px; margin: 0 auto; background: #fff; padding: 25px; border-radius: 8px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); }
        table { width: 100%; border-collapse: collapse; margin-top: 15px; }
        table, th, td { border: 1px solid #ddd; }
        th, td { padding: 8px; text-align: left; font-size: 13px; }
        th { background: #f2f2f2; }
        select { padding: 5px; }
        button { background: #007bff; color: white; border: none; padding: 6px 12px; border-radius: 4px; cursor: pointer; }
        button:hover { background: #0056b3; }
    </style>
</head>
<body>
    <div class="container">
        <h2>Assign Unassigned Open Complaints</h2>
        <p><a href="admin_controller.php?action=dashboard">&larr; Back to Dashboard</a></p>
        <?php if (empty($open_unassigned)): ?>
            <p>There are no unassigned open complaints.</p>
        <?php else: ?>
            <table>
                <tr><th>ID</th><th>Product</th><th>Category</th><th>Description</th><th>Assign to Technician</th></tr>
                <?php foreach ($open_unassigned as $c): ?>
                <tr>
                    <td>#<?php echo $c['complaint_id']; ?></td>
                    <td><?php echo htmlspecialchars($c['product_name']); ?></td>
                    <td><?php echo htmlspecialchars($c['type_name']); ?></td>
                    <td><?php echo htmlspecialchars(substr($c['description'], 0, 50)) . '...'; ?></td>
                    <td>
                        <form action="admin_controller.php" method="POST" style="display:flex; gap:10px;">
                            <input type="hidden" name="complaint_id" value="<?php echo $c['complaint_id']; ?>">
                            <select name="employee_id" required>
                                <option value="">-- Select Technician --</option>
                                <?php foreach ($technicians as $tech): ?>
                                    <option value="<?php echo $tech['employee_id']; ?>"><?php echo htmlspecialchars($tech['last_name'] . ', ' . $tech['first_name']); ?></option>
                                <?php endforeach; ?>
                            </select>
                            <button type="submit" name="assign_complaint">Assign</button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; ?>
            </table>
        <?php endif; ?>
    </div>
</body>
</html>