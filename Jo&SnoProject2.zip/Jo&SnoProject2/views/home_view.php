<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Jo & Sno Mining - Portal</title>
    <style>
        body { font-family: Arial, sans-serif; background: #f4f6f9; margin: 0; padding: 40px; }
        .container { max-width: 600px; margin: 0 auto; background: #fff; padding: 30px; border-radius: 8px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); text-align: center; }
        h1 { color: #1b365d; }
        .btn-group { margin-top: 20px; display: flex; justify-content: space-around; }
        .btn { background: #007bff; color: white; padding: 12px 20px; text-decoration: none; border-radius: 4px; font-weight: bold; }
        .btn:hover { background: #0056b3; }
        .btn-secondary { background: #28a745; }
        .btn-secondary:hover { background: #218838; }
    </style>
</head>
<body>
    <div class="container">
        <h1>Jo & Sno Mining & Support Portal</h1>
        <p>Please select your portal to continue:</p>
        <div class="btn-group">
            <a href="views/customer_login.php" class="btn">Customer Portal</a>
            <a href="views/employee_login.php" class="btn btn-secondary">Employee / Admin Portal</a>
        </div>
    </div>
</body>
</html>