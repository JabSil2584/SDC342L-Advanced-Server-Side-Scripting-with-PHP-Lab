<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Manage Customers</title>
    <style>
        body { font-family: Arial, sans-serif; background: #f4f6f9; padding: 20px; }
        .container { max-width: 900px; margin: 0 auto; background: #fff; padding: 25px; border-radius: 8px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); }
        table { width: 100%; border-collapse: collapse; margin-top: 15px; }
        table, th, td { border: 1px solid #ddd; }
        th, td { padding: 8px; text-align: left; font-size: 13px; }
        th { background: #f2f2f2; }
    </style>
</head>
<body>
    <div class="container">
        <h2>Customer Accounts List</h2>
        <p><a href="admin_controller.php?action=dashboard">&larr; Back to Dashboard</a></p>
        <table>
            <tr><th>ID</th><th>Name</th><th>Email</th><th>City, State</th><th>Phone</th><th>Action</th></tr>
            <?php foreach ($customers as $cust): ?>
            <tr>
                <td><?php echo $cust['customer_id']; ?></td>
                <td><?php echo htmlspecialchars($cust['last_name'] . ', ' . $cust['first_name']); ?></td>
                <td><?php echo htmlspecialchars($cust['email']); ?></td>
                <td><?php echo htmlspecialchars($cust['city'] . ', ' . $cust['state']); ?></td>
                <td><?php echo htmlspecialchars($cust['phone_number']); ?></td>
                <td><a href="admin_controller.php?action=edit_customer&id=<?php echo $cust['customer_id']; ?>">Edit</a></td>
            </tr>
            <?php endforeach; ?>
        </table>
    </div>
</body>
</html>