<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Change Password</title>
    <style>
        body { font-family: Arial, sans-serif; background: #f4f6f9; padding: 40px; }
        .card { max-width: 400px; margin: 0 auto; background: #fff; padding: 25px; border-radius: 8px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); }
        .form-group { margin-bottom: 15px; }
        label { display: block; font-weight: bold; margin-bottom: 5px; }
        input { width: 100%; padding: 8px; box-sizing: border-box; border: 1px solid #ccc; border-radius: 4px; }
        button { width: 100%; padding: 10px; background: #28a745; color: white; border: none; border-radius: 4px; font-size: 16px; cursor: pointer; }
    </style>
</head>
<body>
    <div class="card">
        <h2>Change Password</h2>
        <?php if (!empty($success_msg)): ?><div style="color:green; margin-bottom:10px;"><?php echo $success_msg; ?></div><?php endif; ?>
        <?php if (!empty($error)): ?><div style="color:red; margin-bottom:10px;"><?php echo $error; ?></div><?php endif; ?>
        <form action="technician_controller.php?action=password" method="POST">
            <div class="form-group">
                <label>New Password (min 6 chars)</label>
                <input type="password" name="new_password" minlength="6" required>
            </div>
            <button type="submit" name="change_password">Update Password</button>
        </form>
        <p style="text-align:center; margin-top:15px;"><a href="technician_controller.php?action=dashboard">&larr; Back to Dashboard</a></p>
    </div>
</body>
</html>