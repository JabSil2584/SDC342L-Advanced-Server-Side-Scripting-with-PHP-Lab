<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Customer</title>
    <style>
        body { font-family: Arial, sans-serif; background: #f4f6f9; padding: 40px; }
        .card { max-width: 500px; margin: 0 auto; background: #fff; padding: 25px; border-radius: 8px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); }
        .form-group { margin-bottom: 12px; }
        label { display: block; margin-bottom: 3px; font-weight: bold; }
        input { width: 100%; padding: 8px; box-sizing: border-box; border: 1px solid #ccc; border-radius: 4px; }
        button { width: 100%; padding: 10px; background: #007bff; color: white; border: none; border-radius: 4px; font-size: 16px; cursor: pointer; margin-top: 10px; }
    </style>
</head>
<body>
    <div class="card">
        <h2>Edit Customer Account</h2>
        <form action="admin_controller.php?action=edit_customer&id=<?php echo $customer['customer_id']; ?>" method="POST">
            <div class="form-group"><label>Email</label><input type="email" name="email" value="<?php echo htmlspecialchars($customer['email']); ?>" required></div>
            <div class="form-group"><label>First Name</label><input type="text" name="first_name" value="<?php echo htmlspecialchars($customer['first_name']); ?>" required></div>
            <div class="form-group"><label>Last Name</label><input type="text" name="last_name" value="<?php echo htmlspecialchars($customer['last_name']); ?>" required></div>
            <div class="form-group"><label>Street Address</label><input type="text" name="street_address" value="<?php echo htmlspecialchars($customer['street_address']); ?>" required></div>
            <div class="form-group"><label>City</label><input type="text" name="city" value="<?php echo htmlspecialchars($customer['city']); ?>" required></div>
            <div class="form-group"><label>State</label><input type="text" name="state" maxlength="2" value="<?php echo htmlspecialchars($customer['state']); ?>" required></div>
            <div class="form-group"><label>Zip Code</label><input type="text" name="zip_code" value="<?php echo htmlspecialchars($customer['zip_code']); ?>" required></div>
            <div class="form-group"><label>Phone Number</label><input type="text" name="phone_number" value="<?php echo htmlspecialchars($customer['phone_number']); ?>" required></div>
            <button type="submit">Save Customer</button>
        </form>
        <p style="text-align:center; margin-top:15px;"><a href="admin_controller.php?action=customers">&larr; Back to Customers</a></p>
    </div>
</body>
</html>