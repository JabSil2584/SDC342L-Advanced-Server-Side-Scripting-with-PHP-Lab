<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Technician Dashboard</title>
    <style>
        body { font-family: Arial, sans-serif; background: #f4f6f9; margin: 0; padding: 20px; }
        .container { max-width: 900px; margin: 0 auto; background: #fff; padding: 25px; border-radius: 8px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); }
        .header { display: flex; justify-content: space-between; align-items: center; border-bottom: 2px solid #eee; padding-bottom: 10px; }
        table { width: 100%; border-collapse: collapse; margin-top: 25px; }
        table, th, td { border: 1px solid #ddd; }
        th, td { padding: 10px; text-align: left; font-size: 13px; }
        th { background: #f2f2f2; }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h2>Technician Portal</h2>
            <div>
                <span>Technician: <strong><?php echo htmlspecialchars($_SESSION['first_name']); ?></strong></span> | 
                <a href="technician_controller.php?action=password">Change Password</a> | 
                <a href="../controllers/auth_controller.php?action=logout">Logout</a>
            </div>
        </div>

        <h3>Assigned Complaints</h3>
        <?php if (empty($complaints)): ?>
            <p>No complaints currently assigned to you.</p>
        <?php else: ?>
            <table>
                <tr>
                    <th>ID</th><th>Customer</th><th>Product</th><th>Category</th><th>Status</th><th>Action</th>
                </tr>
                <?php foreach ($complaints as $c): ?>
                <tr>
                    <td>#<?php echo $c['complaint_id']; ?></td>
                    <td><?php echo htmlspecialchars($c['first_name'] . ' ' . $c['last_name']); ?></td>
                    <td><?php echo htmlspecialchars($c['product_name']); ?></td>
                    <td><?php echo htmlspecialchars($c['type_name']); ?></td>
                    <td><strong><?php echo htmlspecialchars($c['status']); ?></strong></td>
                    <td><a href="technician_controller.php?action=update&id=<?php echo $c['complaint_id']; ?>">Update / Resolve</a></td>
                </tr>
                <?php endforeach; ?>
            </table>
        <?php endif; ?>
    </div>
</body>
</html>