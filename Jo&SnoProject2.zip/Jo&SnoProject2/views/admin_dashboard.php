<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Administrator Dashboard</title>
    <style>
        body { font-family: Arial, sans-serif; background: #f4f6f9; margin: 0; padding: 20px; }
        .container { max-width: 1000px; margin: 0 auto; background: #fff; padding: 25px; border-radius: 8px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); }
        .header { display: flex; justify-content: space-between; align-items: center; border-bottom: 2px solid #eee; padding-bottom: 10px; }
        .nav-links { margin: 15px 0; }
        .nav-links a { margin-right: 15px; font-weight: bold; text-decoration: none; color: #007bff; }
        table { width: 100%; border-collapse: collapse; margin-top: 15px; margin-bottom: 30px; }
        table, th, td { border: 1px solid #ddd; }
        th, td { padding: 8px; text-align: left; font-size: 13px; }
        th { background: #f2f2f2; }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h2>Administrator Portal</h2>
            <div>
                <span>Admin: <strong><?php echo htmlspecialchars($_SESSION['first_name']); ?></strong></span> | 
                <a href="../controllers/auth_controller.php?action=logout">Logout</a>
            </div>
        </div>

        <div class="nav-links">
            <a href="admin_controller.php?action=customers">Manage Customers</a>
            <a href="admin_controller.php?action=employees">Manage Employees</a>
            <a href="admin_controller.php?action=assign">Assign Complaints</a>
        </div>

        <h3>Open Complaints (Assigned to Technicians)</h3>
        <?php if (empty($open_assigned)): ?>
            <p>No assigned open complaints.</p>
        <?php else: ?>
            <table>
                <tr><th>ID</th><th>Product</th><th>Category</th><th>Assigned Tech</th><th>Action</th></tr>
                <?php foreach ($open_assigned as $c): ?>
                <tr>
                    <td>#<?php echo $c['complaint_id']; ?></td>
                    <td><?php echo htmlspecialchars($c['product_name']); ?></td>
                    <td><?php echo htmlspecialchars($c['type_name']); ?></td>
                    <td><?php echo htmlspecialchars($c['tech_name']); ?></td>
                    <td><a href="admin_controller.php?action=assign">Reassign</a></td>
                </tr>
                <?php endforeach; ?>
            </table>
        <?php endif; ?>

        <h3>Open Complaints (Unassigned)</h3>
        <?php if (empty($open_unassigned)): ?>
            <p>All open complaints are assigned.</p>
        <?php else: ?>
            <table>
                <tr><th>ID</th><th>Product</th><th>Category</th><th>Action</th></tr>
                <?php foreach ($open_unassigned as $c): ?>
                <tr>
                    <td>#<?php echo $c['complaint_id']; ?></td>
                    <td><?php echo htmlspecialchars($c['product_name']); ?></td>
                    <td><?php echo htmlspecialchars($c['type_name']); ?></td>
                    <td><a href="admin_controller.php?action=assign">Assign Now</a></td>
                </tr>
                <?php endforeach; ?>
            </table>
        <?php endif; ?>

        <h3>Technician Open Complaint Workloads</h3>
        <table>
            <tr><th>Technician ID</th><th>Name</th><th>Open Complaints Count</th></tr>
            <?php foreach ($tech_workloads as $tw): ?>
            <tr>
                <td><?php echo htmlspecialchars($tw['employee_id']); ?></td>
                <td><?php echo htmlspecialchars($tw['first_name'] . ' ' . $tw['last_name']); ?></td>
                <td><strong><?php echo $tw['open_count']; ?></strong></td>
            </tr>
            <?php endforeach; ?>
        </table>
    </div>
</body>
</html>