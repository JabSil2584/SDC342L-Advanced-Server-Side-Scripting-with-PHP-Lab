<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Update Complaint</title>
    <style>
        body { font-family: Arial, sans-serif; background: #f4f6f9; padding: 40px; }
        .card { max-width: 600px; margin: 0 auto; background: #fff; padding: 25px; border-radius: 8px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); }
        .form-group { margin-bottom: 15px; }
        label { display: block; font-weight: bold; margin-bottom: 5px; }
        textarea, select, input { width: 100%; padding: 8px; box-sizing: border-box; border: 1px solid #ccc; border-radius: 4px; }
        button { background: #007bff; color: white; padding: 10px 20px; border: none; border-radius: 4px; cursor: pointer; font-size: 16px; }
        button:hover { background: #0056b3; }
        .error { color: red; margin-bottom: 15px; }
    </style>
</head>
<body>
    <div class="card">
        <h2>Update Complaint #<?php echo $complaint['complaint_id']; ?></h2>
        <p><strong>Customer:</strong> <?php echo htmlspecialchars($complaint['first_name'] . ' ' . $complaint['last_name'] . ' (' . $complaint['email'] . ')'); ?></p>
        <p><strong>Product:</strong> <?php echo htmlspecialchars($complaint['product_name']); ?></p>
        <p><strong>Category:</strong> <?php echo htmlspecialchars($complaint['type_name']); ?></p>
        <p><strong>Customer Description:</strong><br><?php echo nl2br(htmlspecialchars($complaint['description'])); ?></p>
        <?php if (!empty($complaint['image_path'])): ?>
            <p><strong>Attached Image:</strong><br><img src="../<?php echo htmlspecialchars($complaint['image_path']); ?>" style="max-width:300px; border-radius:4px;"></p>
        <?php endif; ?>

        <?php if (!empty($errors)): ?><div class="error"><ul><?php foreach ($errors as $e) echo "<li>$e</li>"; ?></ul></div><?php endif; ?>

        <form action="technician_controller.php" method="POST">
            <input type="hidden" name="complaint_id" value="<?php echo $complaint['complaint_id']; ?>">
            <div class="form-group">
                <label>Technician Notes / Analysis</label>
                <textarea name="technician_notes" rows="4"><?php echo htmlspecialchars($complaint['technician_notes'] ?? ''); ?></textarea>
            </div>
            <div class="form-group">
                <label>Status</label>
                <select name="status">
                    <option value="Open" <?php if ($complaint['status'] === 'Open') echo 'selected'; ?>>Open</option>
                    <option value="Closed" <?php if ($complaint['status'] === 'Closed') echo 'selected'; ?>>Closed (Resolved)</option>
                </select>
            </div>
            <div class="form-group">
                <label>Resolution Date</label>
                <input type="date" name="resolution_date" value="<?php echo htmlspecialchars($complaint['resolution_date'] ?? date('Y-m-d')); ?>">
            </div>
            <div class="form-group">
                <label>Resolution Notes (Required if closing)</label>
                <textarea name="resolution_notes" rows="4"><?php echo htmlspecialchars($complaint['resolution_notes'] ?? ''); ?></textarea>
            </div>
            <button type="submit" name="update_complaint">Save Complaint Update</button>
        </form>
        <p style="margin-top:15px;"><a href="technician_controller.php?action=dashboard">&larr; Back to Dashboard</a></p>
    </div>
</body>
</html>