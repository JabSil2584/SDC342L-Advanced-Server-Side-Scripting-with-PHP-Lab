<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Customer Registration</title>
    <style>
        body { font-family: Arial, sans-serif; background: #f4f6f9; padding: 40px; }
        .card { max-width: 500px; margin: 0 auto; background: #fff; padding: 25px; border-radius: 8px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); }
        .form-group { margin-bottom: 12px; }
        label { display: block; margin-bottom: 3px; font-weight: bold; }
        input { width: 100%; padding: 8px; box-sizing: border-box; border: 1px solid #ccc; border-radius: 4px; }
        button { width: 100%; padding: 10px; background: #28a745; color: white; border: none; border-radius: 4px; font-size: 16px; cursor: pointer; margin-top: 10px; }
        button:hover { background: #218838; }
        .error { background: #f8d7da; color: #721c24; padding: 10px; border-radius: 4px; margin-bottom: 15px; }
    </style>
</head>
<body>
    <div class="card">
        <h2>Customer Registration</h2>
        <?php if (!empty($errors)): ?>
            <div class="error">
                <ul><?php foreach ($errors as $e) echo "<li>$e</li>"; ?></ul>
            </div>
        <?php endif; ?>
        <form action="../controllers/customer_controller.php" method="POST">
            <div class="form-group"><label>Email Address</label><input type="email" name="email" maxlength="100" required></div>
            <div class="form-group"><label>First Name</label><input type="text" name="first_name" maxlength="50" required></div>
            <div class="form-group"><label>Last Name</label><input type="text" name="last_name" maxlength="50" required></div>
            <div class="form-group"><label>Street Address</label><input type="text" name="street_address" maxlength="100" required></div>
            <div class="form-group"><label>City</label><input type="text" name="city" maxlength="50" required></div>
            <div class="form-group"><label>State (2 letters)</label><input type="text" name="state" maxlength="2" required></div>
            <div class="form-group"><label>Zip Code</label><input type="text" name="zip_code" maxlength="10" required></div>
            <div class="form-group"><label>Phone Number</label><input type="text" name="phone_number" maxlength="20" required></div>
            <div class="form-group"><label>Password (min 6 chars)</label><input type="password" name="password" minlength="6" required></div>
            <button type="submit" name="register">Register Account</button>
        </form>
        <p style="text-align:center; margin-top:15px;"><a href="customer_login.php">Already have an account? Log in</a></p>
    </div>
</body>
</html>