<?php
$is_edit = isset($employee) && !empty($employee);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><?php echo $is_edit ? 'Edit Employee' : 'Add Employee'; ?></title>
    <style>
        body { font-family: Arial, sans-serif; background: #f4f6f9; padding: 40px; }
        .card { max-width: 500px; margin: 0 auto; background: #fff; padding: 25px; border-radius: 8px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); }
        .form-group { margin-bottom: 12px; }
        label { display: block; margin-bottom: 3px; font-weight: bold; }
        input, select { width: 100%; padding: 8px; box-sizing: border-box; border: 1px solid #ccc; border-radius: 4px; }
        button { width: 100%; padding: 10px; background: #28a745; color: white; border: none; border-radius: 4px; font-size: 16px; cursor: pointer; margin-top: 10px; }
    </style>
</head>
<body>
    <div class="card">
        <h2><?php echo $is_edit ? 'Edit Employee' : 'Add New Employee'; ?></h2>
        <form action="admin_controller.php" method="POST">
            <input type="hidden" name="is_edit" value="<?php echo $is_edit ? '1' : '0'; ?>">
            <div class="form-group">
                <label>User ID (Employee ID)</label>
                <input type="text" name="employee_id" value="<?php echo htmlspecialchars($employee['employee_id'] ?? ''); ?>" <?php if ($is_edit) echo 'readonly style="background:#e9ecef;"'; ?> required>
            </div>
            <div class="form-group"><label>First Name</label><input type="text" name="first_name" value="<?php echo htmlspecialchars($employee['first_name'] ?? ''); ?>" required></div>
            <div class="form-group"><label>Last Name</label><input type="text" name="last_name" value="<?php echo htmlspecialchars($employee['last_name'] ?? ''); ?>" required></div>
            <div class="form-group"><label>Email Address</label><input type="email" name="email" value="<?php echo htmlspecialchars($employee['email'] ?? ''); ?>" required></div>
            <div class="form-group"><label>Phone Extension</label><input type="text" name="phone_extension" value="<?php echo htmlspecialchars($employee['phone_extension'] ?? ''); ?>"></div>
            <div class="form-group">
                <label>Level</label>
                <select name="level">
                    <option value="Technician" <?php if (($employee['level'] ?? '') === 'Technician') echo 'selected'; ?>>Technician</option>
                    <option value="Administrator" <?php if (($employee['level'] ?? '') === 'Administrator') echo 'selected'; ?>>Administrator</option>
                </select>
            </div>
            <?php if (!$is_edit): ?>
            <div class="form-group"><label>Initial Password</label><input type="password" name="password" placeholder="Default: Pa$$word1" value="Pa$$word1" required></div>
            <?php endif; ?>
            <button type="submit" name="save_employee">Save Employee</button>
        </form>
        <p style="text-align:center; margin-top:15px;"><a href="admin_controller.php?action=employees">&larr; Back to Employees</a></p>
    </div>
</body>
</html>