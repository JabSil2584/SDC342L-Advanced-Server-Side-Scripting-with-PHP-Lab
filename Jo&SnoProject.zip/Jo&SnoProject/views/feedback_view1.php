<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Jo & Sno Mining - Submit Feedback & Support</title>
    <style>
        body { font-family: Arial, sans-serif; background: #f4f6f9; margin: 0; padding: 20px; }
        .container { max-width: 800px; margin: 0 auto; background: #fff; padding: 25px; border-radius: 8px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); }
        .header { display: flex; justify-content: space-between; align-items: center; border-bottom: 2px solid #eee; padding-bottom: 10px; }
        .form-group { margin-bottom: 15px; }
        label { display: block; font-weight: bold; margin-bottom: 5px; }
        select, textarea, input[type="file"] { width: 100%; padding: 10px; box-sizing: border-box; border: 1px solid #ccc; border-radius: 4px; }
        button { background: #28a745; color: #fff; padding: 12px 20px; border: none; border-radius: 4px; cursor: pointer; font-size: 16px; }
        button:hover { background: #218838; }
        .alert-error { background: #f8d7da; color: #721c24; padding: 10px; border-radius: 4px; margin-bottom: 15px; }
        .alert-success { background: #d4edda; color: #155724; padding: 10px; border-radius: 4px; margin-bottom: 15px; }
        table { width: 100%; border-collapse: collapse; margin-top: 25px; }
        table, th, td { border: 1px solid #ddd; }
        th, td { padding: 10px; text-align: left; }
        th { background: #f2f2f2; }
        .badge-open { color: #d9534f; font-weight: bold; }
        .badge-closed { color: #5cb85c; font-weight: bold; }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h2>Crypto & Day Trading Support / Feedback</h2>
            <p>Welcome, <strong><?php echo htmlspecialchars($_SESSION['first_name']); ?></strong></p>
        </div>

        <?php if (!empty($errors)): ?>
            <div class="alert-error">
                <ul>
                    <?php foreach ($errors as $err): ?>
                        <li><?php echo htmlspecialchars($err); ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>

        <?php if (!empty($success_msg)): ?>
            <div class="alert-success"><?php echo htmlspecialchars($success_msg); ?></div>
        <?php endif; ?>

        <h3>Submit New Issue / Feedback</h3>
        <form action="../controllers/feedback_controller.php" method="POST" enctype="multipart/form-warning" enctype="multipart/form-data">
            <div class="form-group">
                <label for="product_id">Product / Service</label>
                <select name="product_id" id="product_id" required>
                    <option value="">-- Select Product or Bot --</option>
                    <?php foreach ($products as $p): ?>
                        <option value="<?php echo $p['product_id']; ?>"><?php echo htmlspecialchars($p['product_name']); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="form-group">
                <label for="type_id">Complaint Category</label>
                <select name="type_id" id="type_id" required>
                    <option value="">-- Select Category --</option>
                    <?php foreach ($complaint_types as $t): ?>
                        <option value="<?php echo $t['type_id']; ?>"><?php echo htmlspecialchars($t['type_name']); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="form-group">
                <label for="description">Detailed Description</label>
                <textarea name="description" id="description" rows="5" maxlength="1000" placeholder="Describe your issue, trading bot behavior, or feature feedback..." required></php></textarea>
            </div>

            <div class="form-group">
                <label for="complaint_image">Upload Issue Screenshot (Optional)</label>
                <input type="file" name="complaint_image" id="complaint_image" accept="image/*">
            </div>

            <button type="submit">Submit Feedback</button>
        </form>

        <hr style="margin-top: 40px;">

        <h3>My Previously Submitted Feedback & Complaints</h3>
        <?php if (empty($my_complaints)): ?>
            <p>No complaints submitted yet.</p>
        <?php else: ?>
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Product</th>
                        <th>Category</th>
                        <th>Description</th>
                        <th>Status</th>
                        <th>Technician Notes</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($my_complaints as $item): ?>
                        <tr>
                            <td>#<?php echo $item['complaint_id']; ?></td>
                            <td><?php echo htmlspecialchars($item['product_name']); ?></td>
                            <td><?php echo htmlspecialchars($item['type_name']); ?></td>
                            <td><?php echo htmlspecialchars($item['description']); ?></td>
                            <td>
                                <span class="<?php echo ($item['status'] === 'Open') ? 'badge-open' : 'badge-closed'; ?>">
                                    <?php echo htmlspecialchars($item['status']); ?>
                                </span>
                            </td>
                            <td><?php echo htmlspecialchars($item['technician_notes'] ?? 'Pending review...'); ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>
</body>
</html>