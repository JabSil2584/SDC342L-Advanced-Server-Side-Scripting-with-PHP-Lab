<?php
require_once 'Models/Database.php';
require_once 'Models/ContactsDB.php';
require_once 'Controllers/Contact.php';
require_once 'Controllers/ContactController.php';

use Models\ContactsDB;
use Controllers\ContactController;

$errors = [];
$formData = null;
$action = $_GET['action'] ?? 'list';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $result = ContactController::validateAndSave($_POST);
    if ($result['success']) {
        header('Location: display_contacts.php');
        exit();
    } else {
        $errors = $result['errors'];
        $formData = $result['contact'];
        $action = isset($_POST['contactNo']) && !empty($_POST['contactNo']) ? 'edit' : 'add';
    }
}

if ($action === 'delete' && isset($_GET['id'])) {
    ContactsDB::deleteContact($_GET['id']);
    header('Location: display_contacts.php');
    exit();
}

if ($action === 'edit' && isset($_GET['id']) && $_SERVER['REQUEST_METHOD'] !== 'POST') {
    $formData = ContactsDB::getContactById($_GET['id']);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>JaBoris Silas week 3 Midterm</title>
   <style>
        body { font-family: Arial, sans-serif; margin: 20px; background: #e8f5e9; color: #333; }
        h1, h2, h3 { color: #4B1869; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; background: #fff; }
        th, td { border: 1px solid #ddd; padding: 8px; text-align: left; font-size: 13px; }
        th { background-color: #4B1869; color: #FFC72C; }
        tr:nth-child(even) { background-color: #f4ecf7; }
        .error { color: red; font-size: 12px; display: block; margin-top: 3px; }
        .form-group { margin-bottom: 12px; }
        label { display: block; font-weight: bold; margin-bottom: 4px; color: #1A472A; }
        input[type="text"], input[type="date"], input[type="email"] { width: 300px; padding: 6px; border: 1px solid #ccc; border-radius: 4px; }
        input[type="text"]:focus, input[type="date"]:focus, input[type="email"]:focus { border-color: #4B1869; outline: none; box-shadow: 0 0 5px rgba(75, 24, 105, 0.3); }
        button, .btn { background: #4B1869; color: #FFC72C; padding: 8px 15px; border: 1px solid #FFC72C; border-radius: 4px; cursor: pointer; text-decoration: none; display: inline-block; font-weight: bold; }
        button:hover, .btn:hover { background: #1A472A; color: #FFC72C; }
        .back-link { margin-bottom: 15px; display: inline-block; color: #4B1869; font-weight: bold; text-decoration: none; }
        .back-link:hover { text-decoration: underline; }
    </style>
</head>
<body>

    <a href="index.php" class="back-link">&larr; Back to Main Menu</a>
    <h1>JaBoris Silas wk3 Midterm</h1>
    <h2>My Contacts</h2>

    <?php if ($action === 'list'): ?>
        <p><a href="display_contacts.php?action=add" class="btn">Add New Contact</a></p>

        <table>
            <thead>
                <tr>
                    <th>User ID</th>
                    <th>Name</th>
                    <th>Street Address</th>
                    <th>Apt/Office/Bldg</th>
                    <th>City</th>
                    <th>State</th>
                    <th>Zip Code</th>
                    <th>DOB</th>
                    <th>E-Mail Address</th>
                    <th>Phone Number</th>
                    <th>Additional Information</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php 
                $contacts = ContactsDB::getAllContacts();
                if (empty($contacts)): 
                ?>
                    <tr><td colspan="12" style="text-align: center;">No contacts found in database.</td></tr>
                <?php else: foreach ($contacts as $c): ?>
                    <tr>
                        <td><?= htmlspecialchars($c->contactNo) ?></td>
                        <td><?= htmlspecialchars($c->lastName . ', ' . $c->firstName) ?></td>
                        <td><?= htmlspecialchars($c->addressLine1) ?></td>
                        <td><?= htmlspecialchars($c->addressLine2) ?></td>
                        <td><?= htmlspecialchars($c->city) ?></td>
                        <td><?= htmlspecialchars($c->state) ?></td>
                        <td><?= htmlspecialchars($c->zip) ?></td>
                        <td><?= htmlspecialchars($c->birthdate) ?></td>
                        <td><?= htmlspecialchars($c->email) ?></td>
                        <td><?= htmlspecialchars($c->phone) ?></td>
                        <td><?= htmlspecialchars($c->notes) ?></td>
                        <td>
                            <a href="display_contacts.php?action=edit&id=<?= $c->contactNo ?>">Edit</a> | 
                            <a href="display_contacts.php?action=delete&id=<?= $c->contactNo ?>" onclick="return confirm('Are you sure you want to delete this contact?');">Delete</a>
                        </td>
                    </tr>
                <?php endforeach; endif; ?>
            </tbody>
        </table>

    <?php else: ?>
        <h3><?= $action === 'edit' ? 'Update Contact' : 'Add New Contact' ?></h3>
        <form method="POST" action="display_contacts.php">
            <?php if ($action === 'edit' && $formData && $formData->contactNo): ?>
                <input type="hidden" name="contactNo" value="<?= htmlspecialchars($formData->contactNo) ?>">
            <?php endif; ?>

            <div class="form-group">
                <label>First Name:</label>
                <input type="text" name="firstName" value="<?= htmlspecialchars($formData->firstName ?? '') ?>">
                <?php if (isset($errors['firstName'])): ?><span class="error"><?= $errors['firstName'] ?></span><?php endif; ?>
            </div>

            <div class="form-group">
                <label>Last Name:</label>
                <input type="text" name="lastName" value="<?= htmlspecialchars($formData->lastName ?? '') ?>">
                <?php if (isset($errors['lastName'])): ?><span class="error"><?= $errors['lastName'] ?></span><?php endif; ?>
            </div>

            <div class="form-group">
                <label>Street Address:</label>
                <input type="text" name="addressLine1" value="<?= htmlspecialchars($formData->addressLine1 ?? '') ?>">
                <?php if (isset($errors['addressLine1'])): ?><span class="error"><?= $errors['addressLine1'] ?></span><?php endif; ?>
            </div>

            <div class="form-group">
                <label>Apt/Office/Bldg (Optional):</label>
                <input type="text" name="addressLine2" value="<?= htmlspecialchars($formData->addressLine2 ?? '') ?>">
            </div>

            <div class="form-group">
                <label>City:</label>
                <input type="text" name="city" value="<?= htmlspecialchars($formData->city ?? '') ?>">
                <?php if (isset($errors['city'])): ?><span class="error"><?= $errors['city'] ?></span><?php endif; ?>
            </div>

            <div class="form-group">
                <label>State (2 upper-case letters):</label>
                <input type="text" name="state" maxlength="2" value="<?= htmlspecialchars($formData->state ?? '') ?>">
                <?php if (isset($errors['state'])): ?><span class="error"><?= $errors['state'] ?></span><?php endif; ?>
            </div>

            <div class="form-group">
                <label>Zip Code (5 numbers):</label>
                <input type="text" name="zip" maxlength="5" value="<?= htmlspecialchars($formData->zip ?? '') ?>">
                <?php if (isset($errors['zip'])): ?><span class="error"><?= $errors['zip'] ?></span><?php endif; ?>
            </div>

            <div class="form-group">
                <label>Date of Birth:</label>
                <input type="date" name="birthdate" value="<?= htmlspecialchars($formData->birthdate ?? '') ?>">
                <?php if (isset($errors['birthdate'])): ?><span class="error"><?= $errors['birthdate'] ?></span><?php endif; ?>
            </div>

            <div class="form-group">
                <label>E-Mail Address:</label>
                <input type="email" name="email" value="<?= htmlspecialchars($formData->email ?? '') ?>">
                <?php if (isset($errors['email'])): ?><span class="error"><?= $errors['email'] ?></span><?php endif; ?>
            </div>

            <div class="form-group">
                <label>Phone Number (Format: (XXX)XXX-XXXX):</label>
                <input type="text" name="phone" placeholder="(123)456-7890" value="<?= htmlspecialchars($formData->phone ?? '') ?>">
                <?php if (isset($errors['phone'])): ?><span class="error"><?= $errors['phone'] ?></span><?php endif; ?>
            </div>

            <div class="form-group">
                <label>Additional Information / Notes (Max 50 chars):</label>
                <input type="text" name="notes" maxlength="50" value="<?= htmlspecialchars($formData->notes ?? '') ?>">
                <?php if (isset($errors['notes'])): ?><span class="error"><?= $errors['notes'] ?></span><?php endif; ?>
            </div>

            <button type="submit">Save Contact</button>
            <a href="display_contacts.php" class="btn" style="background: #666;">Cancel</a>
        </form>
    <?php endif; ?>

</body>
</html>