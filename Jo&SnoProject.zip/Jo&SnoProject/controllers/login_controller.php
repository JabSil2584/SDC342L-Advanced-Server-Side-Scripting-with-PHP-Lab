<?php
// controllers/login_controller.php
session_start();
require_once(__DIR__ . '/../models/customer_model.php');

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = filter_input(INPUT_POST, 'email', FILTER_VALIDATE_EMAIL);
    $password = filter_input(INPUT_POST, 'password', FILTER_DEFAULT);

    if (!$email) {
        $error = 'Please enter a valid email address.';
    } elseif (empty($password) || strlen($password) < 6) {
        $error = 'Password must be at least 6 characters long.';
    } else {
        $customer = get_customer_by_email($email);
        
        // Verifies against hashed password or fallback plaintext check for initial seed data
        if ($customer && (password_verify($password, $customer['password']) || $password === $customer['password'])) {
            $_SESSION['customer_id'] = $customer['customer_id'];
            $_SESSION['first_name'] = $customer['first_name'];
            $_SESSION['last_name'] = $customer['last_name'];
            header('Location: ../controllers/feedback_controller.php');
            exit();
        } else {
            $error = 'Invalid email or password.';
        }
    }
}

include(__DIR__ . '/../views/login_view.php');
?>