<?php
// controllers/feedback_controller.php
session_start();
require_once(__DIR__ . '/../models/customer_model.php');

// Restrict access to logged-in customers
if (!isset($_SESSION['customer_id'])) {
    header('Location: ../controllers/login_controller.php');
    exit();
}

$customer_id = $_SESSION['customer_id'];
$errors = [];
$success_msg = '';

$products = get_all_products();
$complaint_types = get_all_complaint_types();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $product_id = filter_input(INPUT_POST, 'product_id', FILTER_VALIDATE_INT);
    $type_id = filter_input(INPUT_POST, 'type_id', FILTER_VALIDATE_INT);
    $description = trim(filter_input(INPUT_POST, 'description', FILTER_DEFAULT));

    // Field validation checks matching database bounds
    if (!$product_id) {
        $errors[] = 'Please select a valid Crypto Product or Bot Service.';
    }
    if (!$type_id) {
        $errors[] = 'Please select a complaint category.';
    }
    if (empty($description)) {
        $errors[] = 'Description is required.';
    } elseif (strlen($description) < 10 || strlen($description) > 1000) {
        $errors[] = 'Description must be between 10 and 1000 characters.';
    }

    // Image Upload Handler
    $image_path = NULL;
    if (isset($_FILES['complaint_image']) && $_FILES['complaint_image']['error'] === UPLOAD_ERR_OK) {
        $file_tmp = $_FILES['complaint_image']['tmp_name'];
        $file_name = basename($_FILES['complaint_image']['name']);
        $file_ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));
        $allowed_exts = ['jpg', 'jpeg', 'png', 'gif'];

        if (in_array($file_ext, $allowed_exts)) {
            $upload_dir = __DIR__ . '/../uploads/';
            if (!is_dir($upload_dir)) {
                mkdir($upload_dir, 0777, true);
            }
            $new_filename = uniqid('img_', true) . '.' . $file_ext;
            $target_file = $upload_dir . $new_filename;

            if (move_uploaded_file($file_tmp, $target_file)) {
                $image_path = 'uploads/' . $new_filename;
            } else {
                $errors[] = 'Failed to upload image file.';
            }
        } else {
            $errors[] = 'Invalid image format. Allowed formats: JPG, PNG, GIF.';
        }
    }

    if (empty($errors)) {
        if (insert_complaint($customer_id, $product_id, $type_id, $description, $image_path)) {
            $success_msg = 'Your feedback/complaint has been submitted successfully.';
        } else {
            $errors[] = 'Database error: Could not submit complaint.';
        }
    }
}

$my_complaints = get_customer_complaints($customer_id);
include(__DIR__ . '/../views/feedback_view.php');
?>