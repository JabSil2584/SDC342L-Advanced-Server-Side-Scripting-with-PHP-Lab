-- Set database
CREATE DATABASE IF NOT EXISTS `jo&sno` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `jo&sno`;

-- Drop old tables if rebuilding the schema to meet the 5-table requirement
DROP TABLE IF EXISTS `complaints`;
DROP TABLE IF EXISTS `complaint_types`;
DROP TABLE IF EXISTS `products`;
DROP TABLE IF EXISTS `employees`;
DROP TABLE IF EXISTS `customers`;

-- 1. Customers Table (Stores user registration info)
CREATE TABLE `customers` (
  `customer_id` INT AUTO_INCREMENT PRIMARY KEY,
  `email` VARCHAR(100) NOT NULL UNIQUE,
  `first_name` VARCHAR(50) NOT NULL,
  `last_name` VARCHAR(50) NOT NULL,
  `street_address` VARCHAR(100) NOT NULL,
  `city` VARCHAR(50) NOT NULL,
  `state` VARCHAR(2) NOT NULL,
  `zip_code` VARCHAR(10) NOT NULL,
  `phone_number` VARCHAR(20) NOT NULL,
  `password` VARCHAR(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 2. Employees Table (Stores Administrators and Technicians)
CREATE TABLE `employees` (
  `employee_id` VARCHAR(50) PRIMARY KEY, -- User ID
  `first_name` VARCHAR(50) NOT NULL,
  `last_name` VARCHAR(50) NOT NULL,
  `email` VARCHAR(100) NOT NULL UNIQUE,
  `phone_extension` VARCHAR(10),
  `level` ENUM('Administrator', 'Technician') NOT NULL,
  `password` VARCHAR(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 3. Products Table (At least 5 products/services provided)
CREATE TABLE `products` (
  `product_id` INT AUTO_INCREMENT PRIMARY KEY,
  `product_name` VARCHAR(100) NOT NULL,
  `product_description` TEXT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 4. Complaint Types Table (At least 3 complaint types)
CREATE TABLE `complaint_types` (
  `type_id` INT AUTO_INCREMENT PRIMARY KEY,
  `type_name` VARCHAR(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 5. Complaints Table (Relates customers, products, complaint types, and assigned employees)
CREATE TABLE `complaints` (
  `complaint_id` INT AUTO_INCREMENT PRIMARY KEY,
  `customer_id` INT NOT NULL,
  `product_id` INT NOT NULL,
  `type_id` INT NOT NULL,
  `assigned_employee_id` VARCHAR(50) DEFAULT NULL,
  `description` TEXT NOT NULL,
  `image_path` VARCHAR(255) DEFAULT NULL,
  `status` ENUM('Open', 'Closed') DEFAULT 'Open',
  `technician_notes` TEXT DEFAULT NULL,
  `resolution_date` DATE DEFAULT NULL,
  `resolution_notes` TEXT DEFAULT NULL,
  FOREIGN KEY (`customer_id`) REFERENCES `customers`(`customer_id`) ON DELETE CASCADE,
  FOREIGN KEY (`product_id`) REFERENCES `products`(`product_id`) ON DELETE CASCADE,
  FOREIGN KEY (`type_id`) REFERENCES `complaint_types`(`type_id`) ON DELETE CASCADE,
  FOREIGN KEY (`assigned_employee_id`) REFERENCES `employees`(`employee_id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ==========================================
-- SEED DATA: 5 Products / Services
-- ==========================================
INSERT INTO `products` (`product_id`, `product_name`, `product_description`) VALUES
(1, 'Bitaxe Mining Rig', 'Open-source hardware ASIC Bitcoin mining device.'),
(2, 'Crypto Trading Bot (EA)', 'Automated algorithmic trading expert advisor.'),
(3, 'Arbitrage Flash Loan Bot', 'Smart contract tool for multi-chain cross-DEX arbitrage.'),
(4, 'Node Hosting & Setup', 'Managed blockchain node infrastructure support.'),
(5, 'Custom Indicator Development', 'Tailored Pine Script and MQL technical indicators.');

-- ==========================================
-- SEED DATA: 3 Complaint Types
-- ==========================================
INSERT INTO `complaint_types` (`type_id`, `type_name`) VALUES
(1, 'Product Defect'),
(2, 'Warranty Claim'),
(3, 'Software / Setup Assistance');

-- ==========================================
-- SEED DATA: Default Admin & Tech Users
-- ==========================================
INSERT INTO `employees` (`employee_id`, `first_name`, `last_name`, `email`, `phone_extension`, `level`, `password`) VALUES
('admin1', 'System', 'Administrator', 'admin@joandsno.com', '101', 'Administrator', 'Pa$$word1'),
('tech1', 'Lead', 'Technician', 'tech@joandsno.com', '102', 'Technician', 'Pa$$word1');
-- Note: Password for both default users above is 'password' (hashed with password_hash).