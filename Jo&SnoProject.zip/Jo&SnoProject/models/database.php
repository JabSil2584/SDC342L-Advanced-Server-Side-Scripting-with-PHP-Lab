<?php
// models/database.php
$dsn = 'mysql:host=localhost;dbname=jo&sno;charset=utf8mb4';
$username = 'root';
$password = ''; // Default XAMPP password

try {
    $db = new PDO($dsn, $username, $password);
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $db->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $error_message = $e->getMessage();
    die("Database Connection Error: " . $error_message);
}
?>