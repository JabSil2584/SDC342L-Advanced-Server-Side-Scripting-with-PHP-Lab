<?php
// models/customer_model.php
require_once(__DIR__ . '/database.php');

function get_customer_by_email($email) {
    global $db;
    $query = 'SELECT * FROM customers WHERE email = :email';
    $statement = $db->prepare($query);
    $statement->bindValue(':email', $email);
    $statement->execute();
    return $statement->fetch();
}

function get_all_products() {
    global $db;
    $query = 'SELECT * FROM products ORDER BY product_name ASC';
    $statement = $db->prepare($query);
    $statement->execute();
    return $statement->fetchAll();
}

function get_all_complaint_types() {
    global $db;
    $query = 'SELECT * FROM complaint_types ORDER BY type_name ASC';
    $statement = $db->prepare($query);
    $statement->execute();
    return $statement->fetchAll();
}

function insert_complaint($customer_id, $product_id, $type_id, $description, $image_path) {
    global $db;
    $query = 'INSERT INTO complaints (customer_id, product_id, type_id, description, image_path, status)
              VALUES (:customer_id, :product_id, :type_id, :description, :image_path, "Open")';
    $statement = $db->prepare($query);
    $statement->bindValue(':customer_id', $customer_id);
    $statement->bindValue(':product_id', $product_id);
    $statement->bindValue(':type_id', $type_id);
    $statement->bindValue(':description', $description);
    $statement->bindValue(':image_path', $image_path);
    return $statement->execute();
}

function get_customer_complaints($customer_id) {
    global $db;
    $query = 'SELECT c.complaint_id, c.description, c.status, c.technician_notes, c.resolution_notes, c.resolution_date,
                     p.product_name, t.type_name
              FROM complaints c
              JOIN products p ON c.product_id = p.product_id
              JOIN complaint_types t ON c.type_id = t.type_id
              WHERE c.customer_id = :customer_id
              ORDER BY c.complaint_id DESC';
    $statement = $db->prepare($query);
    $statement->bindValue(':customer_id', $customer_id);
    $statement->execute();
    return $statement->fetchAll();
}
?>